<?php return array('dependencies' => array('react', 'wp-api-fetch', 'wp-hooks'), 'version' => '79971bee5b92bf22212b');
