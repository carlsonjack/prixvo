<?php return array('dependencies' => array(), 'version' => '75e509f4966b65ed9036');
