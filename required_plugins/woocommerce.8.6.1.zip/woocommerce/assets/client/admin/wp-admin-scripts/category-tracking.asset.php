<?php return array('dependencies' => array('wc-tracks'), 'version' => 'd4f6ad7cf45c0ed7cce0');
