<?php return array('dependencies' => array('wc-components', 'wc-currency', 'wc-number', 'wp-element'), 'version' => '95b692875bd1ba0fa8f2');
